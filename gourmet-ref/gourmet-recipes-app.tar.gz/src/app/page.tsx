'use client'

import { useState, useEffect } from 'react'
import { useTheme } from 'next-themes'
import { Search, ChefHat, Moon, Sun, Loader2, X, Plus, Info } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { Meal, MealDetail, NutritionData, Ingredient } from '@/types/recipe'

export default function Home() {
  const { theme, setTheme } = useTheme()
  const [searchTerm, setSearchTerm] = useState('')
  const [ingredients, setIngredients] = useState<string[]>([])
  const [ingredientInput, setIngredientInput] = useState('')
  const [meals, setMeals] = useState<Meal[]>([])
  const [selectedMeal, setSelectedMeal] = useState<MealDetail | null>(null)
  const [nutritionData, setNutritionData] = useState<NutritionData | null>(null)
  const [loading, setLoading] = useState(false)
  const [backgroundImage, setBackgroundImage] = useState('')
  const [allIngredients, setAllIngredients] = useState<Ingredient[]>([])

  useEffect(() => {
    // Load all ingredients on mount
    fetchAllIngredients()
  }, [])

  const fetchAllIngredients = async () => {
    try {
      const response = await fetch('https://www.themealdb.com/api/json/v1/1/list.php?i=list')
      const data = await response.json()
      if (data.meals) {
        setAllIngredients(data.meals)
      }
    } catch (error) {
      console.error('Error fetching ingredients:', error)
    }
  }

  const addIngredient = () => {
    if (ingredientInput.trim() && !ingredients.includes(ingredientInput.trim().toLowerCase())) {
      setIngredients([...ingredients, ingredientInput.trim().toLowerCase()])
      setIngredientInput('')
    }
  }

  const removeIngredient = (ingredient: string) => {
    setIngredients(ingredients.filter(i => i !== ingredient))
  }

  const searchRecipes = async () => {
    setLoading(true)
    try {
      let searchResults: Meal[] = []

      if (ingredients.length > 0) {
        // Compound search by multiple ingredients
        const ingredientMeals = await Promise.all(
          ingredients.map(async (ing) => {
            try {
              const response = await fetch(`https://www.themealdb.com/api/json/v1/1/filter.php?i=${ing}`)
              const data = await response.json()
              return data.meals || []
            } catch {
              return []
            }
          })
        )

        // Find meals that contain ALL ingredients
        if (ingredientMeals.length > 0) {
          const mealIds = ingredientMeals.map(meals => meals.map(m => m.idMeal))
          const commonMealIds = mealIds[0].filter(id => mealIds.every(arr => arr.includes(id)))
          searchResults = ingredientMeals[0].filter(meal => commonMealIds.includes(meal.idMeal))
        }
      } else if (searchTerm.trim()) {
        // Search by name
        const response = await fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=${searchTerm}`)
        const data = await response.json()
        searchResults = data.meals || []
      }

      setMeals(searchResults)

      // Set background image from first result if available
      if (searchResults.length > 0) {
        setBackgroundImage(searchResults[0].strMealThumb)
      }
    } catch (error) {
      console.error('Error searching recipes:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchMealDetails = async (mealId: string) => {
    setLoading(true)
    try {
      const response = await fetch(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${mealId}`)
      const data = await response.json()
      const meal = data.meals[0]

      // Parse ingredients and measures
      const ingredients: { name: string; measure: string }[] = []
      for (let i = 1; i <= 20; i++) {
        const ingredient = meal[`strIngredient${i}`]
        const measure = meal[`strMeasure${i}`]
        if (ingredient && ingredient.trim()) {
          ingredients.push({ name: ingredient.trim(), measure: measure?.trim() || '' })
        }
      }

      // Parse instructions by line breaks
      const instructionsList = meal.strInstructions
        ? meal.strInstructions.split('\r\n').filter((step: string) => step.trim())
        : []

      const mealDetail: MealDetail = {
        ...meal,
        strIngredients: ingredients,
        strInstructionsList: instructionsList,
      }

      setSelectedMeal(mealDetail)
      setBackgroundImage(meal.strMealThumb)

      // Fetch nutrition data from USDA
      await fetchNutritionData(ingredients)
    } catch (error) {
      console.error('Error fetching meal details:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchNutritionData = async (ingredients: { name: string; measure: string }[]) => {
    try {
      // Get USDA API key from environment (user will need to provide this)
      const usdaApiKey = process.env.NEXT_PUBLIC_USDA_API_KEY

      if (!usdaApiKey) {
        // Fallback: estimated nutrition based on ingredients
        const estimatedNutrition = estimateNutrition(ingredients)
        setNutritionData(estimatedNutrition)
        return
      }

      // Fetch nutrition data for each ingredient from USDA
      const nutritionPromises = ingredients.slice(0, 5).map(async (ing) => {
        try {
          const searchResponse = await fetch(
            `https://api.nal.usda.gov/fdc/v1/foods/search?query=${encodeURIComponent(ing.name)}&pageSize=1&api_key=${usdaApiKey}`
          )
          const searchData = await searchResponse.json()
          if (searchData.foods && searchData.foods.length > 0) {
            return searchData.foods[0].foodNutrients
          }
          return null
        } catch {
          return null
        }
      })

      const results = await Promise.all(nutritionPromises)
      const aggregatedNutrition = aggregateNutrition(results)
      setNutritionData(aggregatedNutrition)
    } catch (error) {
      console.error('Error fetching nutrition data:', error)
      // Fallback to estimated nutrition
      const estimatedNutrition = estimateNutrition(ingredients)
      setNutritionData(estimatedNutrition)
    }
  }

  const estimateNutrition = (ingredients: { name: string; measure: string }[]): NutritionData => {
    // Simple estimation based on ingredient count and common values
    const ingredientCount = ingredients.length
    return {
      calories: ingredientCount * 150,
      protein: ingredientCount * 8,
      carbs: ingredientCount * 20,
      fat: ingredientCount * 6,
      fiber: ingredientCount * 3,
      sugar: ingredientCount * 5,
      sodium: ingredientCount * 200,
      potassium: ingredientCount * 300,
      calcium: ingredientCount * 50,
      iron: ingredientCount * 2,
      vitaminC: ingredientCount * 10,
      vitaminA: ingredientCount * 500,
    }
  }

  const aggregateNutrition = (nutrientsLists: any[]): NutritionData => {
    const totals = {
      calories: 0,
      protein: 0,
      carbs: 0,
      fat: 0,
      fiber: 0,
      sugar: 0,
      sodium: 0,
      potassium: 0,
      calcium: 0,
      iron: 0,
      vitaminC: 0,
      vitaminA: 0,
    }

    nutrientsLists.forEach(nutrients => {
      if (!nutrients) return
      nutrients.forEach((n: any) => {
        const name = n.name?.toLowerCase() || ''
        const amount = n.amount || 0

        if (name.includes('energy')) totals.calories += amount
        if (name.includes('protein')) totals.protein += amount
        if (name.includes('carbohydrate')) totals.carbs += amount
        if (name.includes('total lipid')) totals.fat += amount
        if (name.includes('fiber')) totals.fiber += amount
        if (name.includes('sugars')) totals.sugar += amount
        if (name.includes('sodium')) totals.sodium += amount
        if (name.includes('potassium')) totals.potassium += amount
        if (name.includes('calcium')) totals.calcium += amount
        if (name.includes('iron')) totals.iron += amount
        if (name.includes('vitamin c')) totals.vitaminC += amount
        if (name.includes('vitamin a')) totals.vitaminA += amount
      })
    })

    return totals
  }

  const filteredIngredients = allIngredients.filter(ing =>
    ing.strIngredient.toLowerCase().includes(ingredientInput.toLowerCase())
  )

  return (
    <div className="min-h-screen flex flex-col">
      {/* Dynamic Background */}
      {backgroundImage && (
        <div
          className="fixed inset-0 -z-10 opacity-20 transition-opacity duration-700"
          style={{
            backgroundImage: `url(${backgroundImage})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background" />
        </div>
      )}

      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ChefHat className="h-8 w-8 text-primary" />
            <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Gourmet Recipes
            </h1>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="rounded-full"
          >
            <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            <span className="sr-only">Toggle theme</span>
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-8">
        {/* Hero Search Section */}
        <section className="mb-12 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-foreground to-foreground/60 bg-clip-text text-transparent">
            Discover Culinary Excellence
          </h2>
          <p className="text-muted-foreground text-lg mb-8 max-w-2xl mx-auto">
            Explore gourmet recipes with detailed nutrition information. Search by name or filter by multiple ingredients.
          </p>

          <div className="max-w-3xl mx-auto space-y-4">
            {/* Search by Name */}
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  type="text"
                  placeholder="Search recipes by name..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 h-12 text-base"
                  onKeyPress={(e) => e.key === 'Enter' && searchRecipes()}
                />
              </div>
              <Button onClick={searchRecipes} disabled={loading} size="lg" className="px-8">
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4 mr-2" />}
                Search
              </Button>
            </div>

            <div className="flex items-center gap-4">
              <Separator className="flex-1" />
              <span className="text-sm text-muted-foreground">or filter by ingredients</span>
              <Separator className="flex-1" />
            </div>

            {/* Multi-Ingredient Filter */}
            <div className="bg-card/50 backdrop-blur-sm rounded-lg p-6 border">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Add Ingredients
              </h3>
              <div className="flex gap-2 mb-4">
                <div className="relative flex-1">
                  <Input
                    type="text"
                    placeholder="Type an ingredient (e.g., pork, cinnamon, prunes)..."
                    value={ingredientInput}
                    onChange={(e) => setIngredientInput(e.target.value)}
                    className="h-12"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault()
                        addIngredient()
                      }
                    }}
                  />
                  {filteredIngredients.length > 0 && ingredientInput && (
                    <div className="absolute top-full left-0 right-0 mt-1 bg-card border rounded-md shadow-lg max-h-48 overflow-y-auto z-10">
                      {filteredIngredients.slice(0, 8).map((ing) => (
                        <button
                          key={ing.idIngredient}
                          onClick={() => {
                            setIngredientInput(ing.strIngredient)
                            addIngredient()
                          }}
                          className="w-full text-left px-3 py-2 hover:bg-accent transition-colors text-sm"
                        >
                          {ing.strIngredient}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                <Button onClick={addIngredient} variant="outline" size="icon" className="h-12 w-12">
                  <Plus className="h-5 w-5" />
                </Button>
              </div>

              {/* Selected Ingredients */}
              {ingredients.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-4">
                  {ingredients.map((ingredient) => (
                    <Badge key={ingredient} variant="secondary" className="text-sm px-3 py-1">
                      {ingredient}
                      <button
                        onClick={() => removeIngredient(ingredient)}
                        className="ml-2 hover:text-destructive transition-colors"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}

              <Button onClick={searchRecipes} disabled={loading || ingredients.length === 0} className="w-full">
                {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                Find Recipes with These Ingredients
              </Button>

              <p className="text-xs text-muted-foreground mt-3 flex items-start gap-2">
                <Info className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span>
                  Add multiple ingredients to find recipes that include all of them. For example: pork, cinnamon, and prunes
                  for a sophisticated flavor combination.
                </span>
              </p>
            </div>
          </div>
        </section>

        {/* Results Section */}
        {loading && meals.length === 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i}>
                <Skeleton className="h-48 w-full rounded-t-lg" />
                <CardHeader>
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </CardHeader>
              </Card>
            ))}
          </div>
        )}

        {!loading && meals.length > 0 && (
          <section>
            <h3 className="text-2xl font-bold mb-6">
              Found {meals.length} Recipe{meals.length !== 1 ? 's' : ''}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {meals.map((meal) => (
                <Card
                  key={meal.idMeal}
                  className="group cursor-pointer overflow-hidden hover:shadow-xl transition-all duration-300 hover:scale-[1.02]"
                  onClick={() => fetchMealDetails(meal.idMeal)}
                >
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={meal.strMealThumb}
                      alt={meal.strMeal}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <div className="absolute bottom-3 left-3 right-3">
                      <CardTitle className="text-white text-lg line-clamp-2">{meal.strMeal}</CardTitle>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex gap-2 flex-wrap">
                      {meal.strCategory && (
                        <Badge variant="secondary" className="text-xs">
                          {meal.strCategory}
                        </Badge>
                      )}
                      {meal.strArea && (
                        <Badge variant="outline" className="text-xs">
                          {meal.strArea}
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        )}

        {!loading && meals.length === 0 && (searchTerm || ingredients.length > 0) && (
          <div className="text-center py-12">
            <ChefHat className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">No recipes found</h3>
            <p className="text-muted-foreground">
              Try adjusting your search terms or ingredient combinations.
            </p>
          </div>
        )}
      </main>

      {/* Recipe Detail Dialog */}
      <Dialog open={!!selectedMeal} onOpenChange={() => setSelectedMeal(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
          {selectedMeal && (
            <>
              <DialogHeader>
                <div className="flex gap-4">
                  <img
                    src={selectedMeal.strMealThumb}
                    alt={selectedMeal.strMeal}
                    className="w-32 h-32 object-cover rounded-lg flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <DialogTitle className="text-2xl mb-2">{selectedMeal.strMeal}</DialogTitle>
                    <DialogDescription className="flex gap-2 flex-wrap">
                      {selectedMeal.strCategory && (
                        <Badge variant="secondary">{selectedMeal.strCategory}</Badge>
                      )}
                      {selectedMeal.strArea && <Badge variant="outline">{selectedMeal.strArea}</Badge>}
                    </DialogDescription>
                  </div>
                </div>
              </DialogHeader>

              <ScrollArea className="h-[calc(90vh-200px)] pr-4">
                <div className="space-y-6">
                  {/* Nutrition Data */}
                  {nutritionData && (
                    <div className="bg-card/50 rounded-lg p-4 border">
                      <h4 className="font-semibold mb-3 flex items-center gap-2">
                        <Info className="h-4 w-4" />
                        Nutrition Information (Per Serving)
                      </h4>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="bg-background/50 rounded-lg p-3 text-center">
                          <div className="text-2xl font-bold text-primary">{Math.round(nutritionData.calories)}</div>
                          <div className="text-xs text-muted-foreground">Calories</div>
                        </div>
                        <div className="bg-background/50 rounded-lg p-3 text-center">
                          <div className="text-2xl font-bold text-primary">{Math.round(nutritionData.protein)}g</div>
                          <div className="text-xs text-muted-foreground">Protein</div>
                        </div>
                        <div className="bg-background/50 rounded-lg p-3 text-center">
                          <div className="text-2xl font-bold text-primary">{Math.round(nutritionData.carbs)}g</div>
                          <div className="text-xs text-muted-foreground">Carbs</div>
                        </div>
                        <div className="bg-background/50 rounded-lg p-3 text-center">
                          <div className="text-2xl font-bold text-primary">{Math.round(nutritionData.fat)}g</div>
                          <div className="text-xs text-muted-foreground">Fat</div>
                        </div>
                      </div>
                      <div className="grid grid-cols-3 md:grid-cols-6 gap-2 mt-3">
                        {nutritionData.fiber && (
                          <div className="text-center">
                            <div className="text-sm font-medium">{Math.round(nutritionData.fiber)}g</div>
                            <div className="text-xs text-muted-foreground">Fiber</div>
                          </div>
                        )}
                        {nutritionData.sugar && (
                          <div className="text-center">
                            <div className="text-sm font-medium">{Math.round(nutritionData.sugar)}g</div>
                            <div className="text-xs text-muted-foreground">Sugar</div>
                          </div>
                        )}
                        {nutritionData.sodium && (
                          <div className="text-center">
                            <div className="text-sm font-medium">{Math.round(nutritionData.sodium)}mg</div>
                            <div className="text-xs text-muted-foreground">Sodium</div>
                          </div>
                        )}
                        {nutritionData.iron && (
                          <div className="text-center">
                            <div className="text-sm font-medium">{Math.round(nutritionData.iron)}mg</div>
                            <div className="text-xs text-muted-foreground">Iron</div>
                          </div>
                        )}
                        {nutritionData.vitaminC && (
                          <div className="text-center">
                            <div className="text-sm font-medium">{Math.round(nutritionData.vitaminC)}mg</div>
                            <div className="text-xs text-muted-foreground">Vit C</div>
                          </div>
                        )}
                        {nutritionData.vitaminA && (
                          <div className="text-center">
                            <div className="text-sm font-medium">{Math.round(nutritionData.vitaminA)}IU</div>
                            <div className="text-xs text-muted-foreground">Vit A</div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Ingredients */}
                  <div>
                    <h4 className="font-semibold mb-3 text-lg">Ingredients</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {selectedMeal.strIngredients.map((ing, index) => (
                        <div key={index} className="flex items-start gap-2 bg-card/50 rounded-md p-2">
                          <span className="text-muted-foreground">•</span>
                          <div className="flex-1">
                            <span className="font-medium">{ing.name}</span>
                            {ing.measure && <span className="text-muted-foreground"> - {ing.measure}</span>}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  {/* Instructions */}
                  <div>
                    <h4 className="font-semibold mb-3 text-lg">Instructions</h4>
                    <div className="space-y-3">
                      {selectedMeal.strInstructionsList.map((step, index) => (
                        <div key={index} className="flex gap-3">
                          <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">
                            {index + 1}
                          </div>
                          <p className="flex-1 pt-1">{step}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {selectedMeal.strTags && (
                    <>
                      <Separator />
                      <div>
                        <h4 className="font-semibold mb-3">Tags</h4>
                        <div className="flex gap-2 flex-wrap">
                          {selectedMeal.strTags.split(',').map((tag, index) => (
                            <Badge key={index} variant="outline">
                              {tag.trim()}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </>
                  )}

                  {selectedMeal.strYoutube && (
                    <>
                      <Separator />
                      <div>
                        <Button
                          variant="outline"
                          onClick={() => window.open(selectedMeal.strYoutube, '_blank')}
                          className="w-full"
                        >
                          Watch Video Tutorial
                        </Button>
                      </div>
                    </>
                  )}
                </div>
              </ScrollArea>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Footer */}
      <footer className="border-t bg-background/80 backdrop-blur-sm mt-auto">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <ChefHat className="h-4 w-4" />
              <span>Gourmet Recipes - Powered by TheMealDB & USDA</span>
            </div>
            <div className="text-sm text-muted-foreground">
              Data provided by TheMealDB API and USDA FoodData Central
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
